package com.example

import com.example.data.model.FileCategory
import com.example.util.FileUtils
import com.example.util.FormatUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testFormatBytes() {
        assertEquals("500 B", FormatUtils.formatBytes(500))
        assertEquals("1.0 KB", FormatUtils.formatBytes(1024))
        assertEquals("10.0 MB", FormatUtils.formatBytes(10 * 1024 * 1024))
        assertEquals("1.5 GB", FormatUtils.formatBytes((1.5 * 1024 * 1024 * 1024).toLong()))
    }

    @Test
    fun testFormatSpeed() {
        assertEquals("0 KB/s", FormatUtils.formatSpeed(0))
        assertEquals("500.0 KB/s", FormatUtils.formatSpeed(500 * 1024))
        assertEquals("4.2 MB/s", FormatUtils.formatSpeed((4.2 * 1024 * 1024).toLong()))
    }

    @Test
    fun testFormatEta() {
        assertEquals("--", FormatUtils.formatEta(0))
        assertEquals("45s", FormatUtils.formatEta(45))
        assertEquals("2m 15s", FormatUtils.formatEta(135))
        assertEquals("1h 10m", FormatUtils.formatEta(4200))
    }

    @Test
    fun testFileCategories() {
        assertEquals(FileCategory.VIDEO, FileUtils.determineCategory("movie.mp4", "video/mp4"))
        assertEquals(FileCategory.AUDIO, FileUtils.determineCategory("track.mp3", "audio/mpeg"))
        assertEquals(FileCategory.IMAGE, FileUtils.determineCategory("photo.png", "image/png"))
        assertEquals(FileCategory.DOCUMENT, FileUtils.determineCategory("paper.pdf", "application/pdf"))
        assertEquals(FileCategory.ARCHIVE, FileUtils.determineCategory("bundle.zip", "application/zip"))
    }

    @Test
    fun testCleanFileName() {
        val cleaned = FileUtils.cleanFileName("my:invalid*filename.zip?token=123#frag")
        assertEquals("my_invalid_filename.zip", cleaned)
    }
}
