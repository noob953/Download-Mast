package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.DownloadTaskCard
import com.example.ui.components.RenameFileDialog
import com.example.ui.components.SpeedIndicator
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.PausedAmber
import com.example.ui.viewmodel.DownloadViewModel
import com.example.util.FileUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActiveDownloadsScreen(
    viewModel: DownloadViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToNewDownload: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }
    val context = LocalContext.current
    val activeTasks by viewModel.activeTasks.collectAsState()
    val totalSpeed by viewModel.totalActiveSpeed.collectAsState()

    var renamingTaskId by remember { mutableStateOf<String?>(null) }
    var renamingCurrentName by remember { mutableStateOf("") }

    if (renamingTaskId != null) {
        RenameFileDialog(
            currentName = renamingCurrentName,
            onDismiss = { renamingTaskId = null },
            onConfirm = { newName ->
                renamingTaskId?.let { id ->
                    viewModel.renameDownload(id, newName) {}
                }
                renamingTaskId = null
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Em Andamento", fontWeight = FontWeight.Bold)
                        if (activeTasks.isNotEmpty()) {
                            Text(
                                text = " (${activeTasks.size})",
                                fontSize = 16.sp,
                                color = CyanPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("active_downloads_back_button")
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Voltar")
                    }
                },
                actions = {
                    SpeedIndicator(bytesPerSec = totalSpeed, modifier = Modifier.padding(end = 12.dp))
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onNavigateToNewDownload,
                containerColor = CyanPrimary,
                contentColor = Color(0xFF003642),
                modifier = Modifier.testTag("active_screen_fab_add")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Novo Download")
            }
        }
    ) { innerPadding ->
        if (activeTasks.isEmpty()) {
            Column(
                modifier = modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(CyanPrimary.copy(alpha = 0.1f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = null,
                        tint = CyanPrimary,
                        modifier = Modifier.size(40.dp)
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Nenhum download em andamento",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Todos os downloads estão concluídos ou pausados.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    onClick = onNavigateToNewDownload,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary)
                ) {
                    Icon(Icons.Default.Add, null, tint = Color(0xFF003642))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Adicionar Download", color = Color(0xFF003642), fontWeight = FontWeight.Bold)
                }
            }
        } else {
            LazyColumn(
                modifier = modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .testTag("active_downloads_list"),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header quick pause all
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Downloads ativos",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedButton(
                            onClick = {
                                activeTasks.forEach { viewModel.pauseDownload(it.id) }
                            },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("pause_all_button")
                        ) {
                            Icon(Icons.Default.Pause, null, modifier = Modifier.size(16.dp), tint = PausedAmber)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Pausar Todos", fontSize = 12.sp, color = PausedAmber)
                        }
                    }
                }

                items(activeTasks, key = { it.id }) { task ->
                    DownloadTaskCard(
                        task = task,
                        onPause = { viewModel.pauseDownload(it) },
                        onResume = { viewModel.resumeDownload(it) },
                        onCancel = { viewModel.cancelDownload(it) },
                        onRetry = { viewModel.retryDownload(it) },
                        onOpen = { path, mime -> FileUtils.openFile(context, path, mime) },
                        onShare = { path, mime -> FileUtils.shareFile(context, path, mime) },
                        onRename = { id ->
                            renamingTaskId = id
                            renamingCurrentName = task.fileName
                        },
                        onDelete = { viewModel.deleteDownload(it) }
                    )
                }
            }
        }
    }
}
