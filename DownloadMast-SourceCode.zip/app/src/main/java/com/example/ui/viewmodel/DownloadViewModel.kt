package com.example.ui.viewmodel

import android.content.Context
import android.os.Environment
import android.os.StatFs
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.DownloadMastApplication
import com.example.data.local.DownloadChunkEntity
import com.example.data.local.DownloadTaskEntity
import com.example.data.model.FileCategory
import com.example.data.model.UrlMetadata
import com.example.data.preferences.UserPreferences
import com.example.engine.UrlInspector
import com.example.util.FormatUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class StorageInfo(
    val availableBytes: Long,
    val totalBytes: Long,
    val appUsedBytes: Long
) {
    val usedPercentage: Float = if (totalBytes > 0) {
        ((totalBytes - availableBytes).toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f)
    } else 0f

    val formattedAvailable: String = FormatUtils.formatBytes(availableBytes)
    val formattedTotal: String = FormatUtils.formatBytes(totalBytes)
    val formattedAppUsed: String = FormatUtils.formatBytes(appUsedBytes)
}

data class UrlInspectionUiState(
    val isLoading: Boolean = false,
    val metadata: UrlMetadata? = null,
    val error: String? = null
)

class DownloadViewModel(
    private val app: DownloadMastApplication = DownloadMastApplication.instance
) : ViewModel() {

    private val dao = app.database.downloadDao()
    private val engine = app.downloadEngine
    private val prefs = app.preferencesManager
    private val inspector = UrlInspector()

    val userPreferences: StateFlow<UserPreferences> = prefs.userPreferences

    val totalActiveSpeed: StateFlow<Long> = engine.totalActiveSpeed
    val activeTasksCount: StateFlow<Int> = engine.activeDownloadsCount

    val activeTasks: StateFlow<List<DownloadTaskEntity>> = dao.getActiveTasks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val completedTasks: StateFlow<List<DownloadTaskEntity>> = dao.getCompletedTasks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pausedTasks: StateFlow<List<DownloadTaskEntity>> = dao.getPausedTasks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val historyTasks: StateFlow<List<DownloadTaskEntity>> = dao.getHistoryTasks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentTasks: StateFlow<List<DownloadTaskEntity>> = dao.getRecentTasks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // File Manager filters
    private val _selectedCategory = MutableStateFlow(FileCategory.ALL)
    val selectedCategory: StateFlow<FileCategory> = _selectedCategory.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val filteredFiles: StateFlow<List<DownloadTaskEntity>> = combine(
        completedTasks,
        _selectedCategory,
        _searchQuery
    ) { files, category, query ->
        files.filter { item ->
            val matchesCategory = (category == FileCategory.ALL) || (item.category == category)
            val matchesQuery = query.isBlank() || item.fileName.contains(query, ignoreCase = true)
            matchesCategory && matchesQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // URL Inspection state
    private val _inspectionState = MutableStateFlow(UrlInspectionUiState())
    val inspectionState: StateFlow<UrlInspectionUiState> = _inspectionState.asStateFlow()

    // Storage info
    private val _storageInfo = MutableStateFlow(calculateStorage())
    val storageInfo: StateFlow<StorageInfo> = _storageInfo.asStateFlow()

    init {
        refreshStorage()
    }

    fun inspectUrl(url: String) {
        if (url.isBlank()) return
        viewModelScope.launch {
            _inspectionState.value = UrlInspectionUiState(isLoading = true)
            val result = inspector.inspectUrl(url)
            if (result.isReachable) {
                _inspectionState.value = UrlInspectionUiState(isLoading = false, metadata = result)
            } else {
                _inspectionState.value = UrlInspectionUiState(
                    isLoading = false,
                    error = result.errorMessage ?: "Não foi possível conectar ao endereço."
                )
            }
        }
    }

    fun clearInspection() {
        _inspectionState.value = UrlInspectionUiState()
    }

    fun startDownload(url: String, fileName: String?, threads: Int) {
        viewModelScope.launch {
            engine.enqueueDownload(url, fileName, threads)
            clearInspection()
            refreshStorage()
        }
    }

    fun pauseDownload(taskId: String) {
        engine.pauseDownload(taskId)
    }

    fun resumeDownload(taskId: String) {
        engine.resumeDownload(taskId)
    }

    fun cancelDownload(taskId: String) {
        engine.cancelDownload(taskId)
        refreshStorage()
    }

    fun retryDownload(taskId: String) {
        engine.retryDownload(taskId)
    }

    fun deleteDownload(taskId: String, deleteFile: Boolean = true) {
        viewModelScope.launch {
            engine.deleteDownload(taskId, deleteFile)
            refreshStorage()
        }
    }

    fun renameDownload(taskId: String, newName: String, onComplete: (Boolean) -> Unit) {
        viewModelScope.launch {
            val result = engine.renameDownload(taskId, newName)
            onComplete(result)
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            dao.clearHistory()
            refreshStorage()
        }
    }

    fun selectCategory(category: FileCategory) {
        _selectedCategory.value = category
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun updateMaxConcurrent(count: Int) = prefs.updateMaxConcurrentDownloads(count)
    fun updateMaxThreads(count: Int) = prefs.updateMaxThreadsPerDownload(count)
    fun updateWifiOnly(wifiOnly: Boolean) = prefs.updateDownloadOnlyOnWifi(wifiOnly)
    fun updateNotifications(show: Boolean) = prefs.updateShowCompletionNotification(show)
    fun updateAutoRetry(retry: Boolean) = prefs.updateAutoRetryOnFailure(retry)
    fun updateThemeMode(mode: String) = prefs.updateThemeMode(mode)
    fun updateSpeedLimit(limitKbps: Int) = prefs.updateSpeedLimitKbps(limitKbps)

    fun refreshStorage() {
        viewModelScope.launch(Dispatchers.IO) {
            _storageInfo.value = calculateStorage()
        }
    }

    private fun calculateStorage(): StorageInfo {
        return try {
            val stat = StatFs(Environment.getDataDirectory().path)
            val available = stat.availableBytes
            val total = stat.totalBytes

            val downloadDir = engine.getDownloadDirectory()
            val appUsed = calculateDirectorySize(downloadDir)

            StorageInfo(
                availableBytes = available,
                totalBytes = total,
                appUsedBytes = appUsed
            )
        } catch (_: Exception) {
            StorageInfo(availableBytes = 0L, totalBytes = 0L, appUsedBytes = 0L)
        }
    }

    private fun calculateDirectorySize(dir: File): Long {
        if (!dir.exists()) return 0L
        var size = 0L
        dir.listFiles()?.forEach { file ->
            size += if (file.isDirectory) calculateDirectorySize(file) else file.length()
        }
        return size
    }

    suspend fun getChunksForTask(taskId: String): List<DownloadChunkEntity> = withContext(Dispatchers.IO) {
        dao.getChunksForTask(taskId)
    }
}
