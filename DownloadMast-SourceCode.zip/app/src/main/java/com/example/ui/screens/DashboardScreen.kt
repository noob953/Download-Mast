package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PauseCircle
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.DownloadTaskCard
import com.example.ui.components.RenameFileDialog
import com.example.ui.components.SpeedIndicator
import com.example.ui.components.StorageCard
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.SpeedAccentGreen
import com.example.ui.viewmodel.DownloadViewModel
import com.example.util.FileUtils
import com.example.util.FormatUtils

@Composable
fun DashboardScreen(
    viewModel: DownloadViewModel,
    onNavigateToNewDownload: () -> Unit,
    onNavigateToActive: () -> Unit,
    onNavigateToCompleted: () -> Unit,
    onNavigateToPaused: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val totalSpeed by viewModel.totalActiveSpeed.collectAsState()
    val activeCount by viewModel.activeTasksCount.collectAsState()
    val activeTasks by viewModel.activeTasks.collectAsState()
    val completedTasks by viewModel.completedTasks.collectAsState()
    val pausedTasks by viewModel.pausedTasks.collectAsState()
    val recentTasks by viewModel.recentTasks.collectAsState()
    val storageInfo by viewModel.storageInfo.collectAsState()

    var renamingTaskId by remember { mutableStateOf<String?>(null) }
    var renamingCurrentName by remember { mutableStateOf("") }

    if (renamingTaskId != null) {
        RenameFileDialog(
            currentName = renamingCurrentName,
            onDismiss = { renamingTaskId = null },
            onConfirm = { newName ->
                renamingTaskId?.let { id ->
                    viewModel.renameDownload(id, newName) {}
                }
                renamingTaskId = null
            }
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("dashboard_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Header with Banner Graphic
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp))
            ) {
                Image(
                    painter = painterResource(id = R.drawable.banner_download_mast),
                    contentDescription = "Download Mast Banner",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                // Dark gradient overlay
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color(0xDD0A0F1D))
                            )
                        )
                )

                // Overlay Content
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.Bottom
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Column {
                            Text(
                                text = "Download Mast",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                            Text(
                                text = "Aceleração Multi-Segmento Ativa",
                                fontSize = 12.sp,
                                color = CyanPrimary,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        SpeedIndicator(bytesPerSec = totalSpeed)
                    }
                }
            }
        }

        // Quick Stats Row
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Active Card
                StatCard(
                    title = "Ativos",
                    value = activeCount.toString(),
                    icon = Icons.Default.Download,
                    accentColor = CyanPrimary,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onNavigateToActive() }
                        .testTag("stat_card_active")
                )

                // Completed Card
                StatCard(
                    title = "Concluídos",
                    value = completedTasks.size.toString(),
                    icon = Icons.Default.CheckCircle,
                    accentColor = SpeedAccentGreen,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onNavigateToCompleted() }
                        .testTag("stat_card_completed")
                )

                // Paused Card
                StatCard(
                    title = "Pausados",
                    value = pausedTasks.size.toString(),
                    icon = Icons.Default.PauseCircle,
                    accentColor = Color(0xFFFFB74D),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onNavigateToPaused() }
                        .testTag("stat_card_paused")
                )
            }
        }

        // Quick Add Download Button
        item {
            Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                Button(
                    onClick = onNavigateToNewDownload,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("dashboard_add_download_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary)
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = null,
                        tint = Color(0xFF003642)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Adicionar Novo Download",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF003642)
                    )
                }
            }
        }

        // Storage indicator
        item {
            Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                StorageCard(storageInfo = storageInfo)
            }
        }

        // Active Downloads section (if any)
        if (activeTasks.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Em Andamento (${activeTasks.size})",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    TextButton(onClick = onNavigateToActive) {
                        Text("Ver Todos", color = CyanPrimary, fontSize = 13.sp)
                    }
                }
            }

            items(activeTasks.take(3), key = { it.id }) { task ->
                Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                    DownloadTaskCard(
                        task = task,
                        onPause = { viewModel.pauseDownload(it) },
                        onResume = { viewModel.resumeDownload(it) },
                        onCancel = { viewModel.cancelDownload(it) },
                        onRetry = { viewModel.retryDownload(it) },
                        onOpen = { path, mime -> FileUtils.openFile(context, path, mime) },
                        onShare = { path, mime -> FileUtils.shareFile(context, path, mime) },
                        onRename = { id ->
                            renamingTaskId = id
                            renamingCurrentName = task.fileName
                        },
                        onDelete = { viewModel.deleteDownload(it) }
                    )
                }
            }
        }

        // Recent Downloads section
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Downloads Recentes",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                if (recentTasks.isNotEmpty()) {
                    TextButton(onClick = onNavigateToCompleted) {
                        Text("Histórico", color = CyanPrimary, fontSize = 13.sp)
                    }
                }
            }
        }

        if (recentTasks.isEmpty() && activeTasks.isEmpty()) {
            item {
                EmptyDashboardState(onAddClick = onNavigateToNewDownload)
            }
        } else {
            items(recentTasks, key = { it.id }) { task ->
                Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                    DownloadTaskCard(
                        task = task,
                        onPause = { viewModel.pauseDownload(it) },
                        onResume = { viewModel.resumeDownload(it) },
                        onCancel = { viewModel.cancelDownload(it) },
                        onRetry = { viewModel.retryDownload(it) },
                        onOpen = { path, mime -> FileUtils.openFile(context, path, mime) },
                        onShare = { path, mime -> FileUtils.shareFile(context, path, mime) },
                        onRename = { id ->
                            renamingTaskId = id
                            renamingCurrentName = task.fileName
                        },
                        onDelete = { viewModel.deleteDownload(it) }
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Column(
            modifier = Modifier.padding(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(accentColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = value,
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = title,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun EmptyDashboardState(onAddClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(CyanPrimary.copy(alpha = 0.1f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Download,
                contentDescription = null,
                tint = CyanPrimary,
                modifier = Modifier.size(36.dp)
            )
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Nenhum download ativo",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Insira um link HTTP ou HTTPS para iniciar downloads ultra-rápidos e segmentados.",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
    }
}
