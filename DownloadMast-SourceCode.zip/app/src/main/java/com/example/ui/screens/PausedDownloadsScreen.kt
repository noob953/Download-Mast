package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.PauseCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.DownloadTaskCard
import com.example.ui.components.RenameFileDialog
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.PausedAmber
import com.example.ui.viewmodel.DownloadViewModel
import com.example.util.FileUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PausedDownloadsScreen(
    viewModel: DownloadViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }
    val context = LocalContext.current
    val pausedTasks by viewModel.pausedTasks.collectAsState()

    var renamingTaskId by remember { mutableStateOf<String?>(null) }
    var renamingCurrentName by remember { mutableStateOf("") }

    if (renamingTaskId != null) {
        RenameFileDialog(
            currentName = renamingCurrentName,
            onDismiss = { renamingTaskId = null },
            onConfirm = { newName ->
                renamingTaskId?.let { id ->
                    viewModel.renameDownload(id, newName) {}
                }
                renamingTaskId = null
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Pausados", fontWeight = FontWeight.Bold)
                        if (pausedTasks.isNotEmpty()) {
                            Text(
                                text = " (${pausedTasks.size})",
                                fontSize = 16.sp,
                                color = PausedAmber,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("paused_downloads_back_button")
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Voltar")
                    }
                },
                actions = {
                    if (pausedTasks.isNotEmpty()) {
                        OutlinedButton(
                            onClick = {
                                pausedTasks.forEach { viewModel.resumeDownload(it.id) }
                            },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.padding(end = 12.dp).testTag("resume_all_button")
                        ) {
                            Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(16.dp), tint = CyanPrimary)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Retomar Todos", fontSize = 12.sp, color = CyanPrimary)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        if (pausedTasks.isEmpty()) {
            Column(
                modifier = modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(PausedAmber.copy(alpha = 0.1f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PauseCircle,
                        contentDescription = null,
                        tint = PausedAmber,
                        modifier = Modifier.size(40.dp)
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Nenhum download pausado",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Downloads pausados manterão seu progresso para você retomar a qualquer momento.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                modifier = modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .testTag("paused_downloads_list"),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(pausedTasks, key = { it.id }) { task ->
                    DownloadTaskCard(
                        task = task,
                        onPause = { viewModel.pauseDownload(it) },
                        onResume = { viewModel.resumeDownload(it) },
                        onCancel = { viewModel.cancelDownload(it) },
                        onRetry = { viewModel.retryDownload(it) },
                        onOpen = { path, mime -> FileUtils.openFile(context, path, mime) },
                        onShare = { path, mime -> FileUtils.shareFile(context, path, mime) },
                        onRename = { id ->
                            renamingTaskId = id
                            renamingCurrentName = task.fileName
                        },
                        onDelete = { viewModel.deleteDownload(it) }
                    )
                }
            }
        }
    }
}
