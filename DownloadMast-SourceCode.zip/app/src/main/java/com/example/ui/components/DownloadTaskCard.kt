package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.DownloadTaskEntity
import com.example.data.model.DownloadStatus
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.PausedAmber
import com.example.ui.theme.SpeedAccentGreen
import com.example.util.FormatUtils

@Composable
fun DownloadTaskCard(
    task: DownloadTaskEntity,
    onPause: (String) -> Unit,
    onResume: (String) -> Unit,
    onCancel: (String) -> Unit,
    onRetry: (String) -> Unit,
    onOpen: (String, String) -> Unit,
    onShare: (String, String) -> Unit,
    onRename: (String) -> Unit,
    onDelete: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showMenu by remember { mutableStateOf(false) }

    val progress = when {
        task.status == DownloadStatus.COMPLETED -> 1f
        task.fileSize > 0 -> (task.downloadedBytes.toFloat() / task.fileSize.toFloat()).coerceIn(0f, 1f)
        else -> 0f
    }
    val percentage = (progress * 100).toInt()

    val statusColor = when (task.status) {
        DownloadStatus.DOWNLOADING -> CyanPrimary
        DownloadStatus.CONNECTING -> CyanPrimary
        DownloadStatus.COMPLETED -> SpeedAccentGreen
        DownloadStatus.PAUSED -> PausedAmber
        DownloadStatus.FAILED -> ErrorRed
        DownloadStatus.PENDING -> Color.Gray
        DownloadStatus.CANCELLED -> Color.Gray
    }

    val statusLabel = when (task.status) {
        DownloadStatus.PENDING -> "Na fila"
        DownloadStatus.CONNECTING -> "Conectando…"
        DownloadStatus.DOWNLOADING -> "Baixando ($percentage%)"
        DownloadStatus.PAUSED -> "Pausado ($percentage%)"
        DownloadStatus.COMPLETED -> "Concluído"
        DownloadStatus.FAILED -> "Falha"
        DownloadStatus.CANCELLED -> "Cancelado"
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .animateContentSize()
            .testTag("download_card_${task.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Category icon badge
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(statusColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = getCategoryIcon(task.category),
                        contentDescription = null,
                        tint = statusColor,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                // Name and status
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = task.fileName,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(statusColor)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = statusLabel,
                            fontSize = 12.sp,
                            color = statusColor,
                            fontWeight = FontWeight.Medium
                        )

                        if (task.threadCount > 1 && task.status == DownloadStatus.DOWNLOADING) {
                            Text(
                                text = " • ${task.threadCount} conexões",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // Top right actions
                Box {
                    IconButton(
                        onClick = { showMenu = true },
                        modifier = Modifier.size(36.dp).testTag("menu_button_${task.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "Mais opções",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        if (task.status == DownloadStatus.COMPLETED) {
                            DropdownMenuItem(
                                text = { Text("Abrir") },
                                leadingIcon = { Icon(Icons.Default.OpenInNew, null) },
                                onClick = {
                                    showMenu = false
                                    onOpen(task.destinationPath, task.mimeType)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Compartilhar") },
                                leadingIcon = { Icon(Icons.Default.Share, null) },
                                onClick = {
                                    showMenu = false
                                    onShare(task.destinationPath, task.mimeType)
                                }
                            )
                        }
                        DropdownMenuItem(
                            text = { Text("Renomear") },
                            leadingIcon = { Icon(Icons.Default.Edit, null) },
                            onClick = {
                                showMenu = false
                                onRename(task.id)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Excluir") },
                            leadingIcon = { Icon(Icons.Default.Delete, null, tint = ErrorRed) },
                            onClick = {
                                showMenu = false
                                onDelete(task.id)
                            }
                        )
                    }
                }
            }

            // Progress bar
            if (task.status == DownloadStatus.DOWNLOADING || task.status == DownloadStatus.PAUSED || task.status == DownloadStatus.CONNECTING) {
                Spacer(modifier = Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { if (task.fileSize > 0) progress else 0f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = statusColor,
                    trackColor = MaterialTheme.colorScheme.surface
                )
            }

            // Detail metrics & Action bar
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Size & Speed info
                Column {
                    val sizeText = if (task.fileSize > 0) {
                        "${FormatUtils.formatBytes(task.downloadedBytes)} / ${FormatUtils.formatBytes(task.fileSize)}"
                    } else {
                        FormatUtils.formatBytes(task.downloadedBytes)
                    }
                    Text(
                        text = sizeText,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    if (task.status == DownloadStatus.DOWNLOADING && task.speedBytesPerSec > 0) {
                        val etaText = FormatUtils.formatEta(task.etaSeconds)
                        Text(
                            text = "${FormatUtils.formatSpeed(task.speedBytesPerSec)} • Restam $etaText",
                            fontSize = 11.sp,
                            color = CyanPrimary,
                            fontWeight = FontWeight.Medium
                        )
                    } else if (task.status == DownloadStatus.COMPLETED && task.completedAt != null) {
                        Text(
                            text = FormatUtils.formatDate(task.completedAt),
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else if (task.status == DownloadStatus.FAILED && task.errorMessage != null) {
                        Text(
                            text = task.errorMessage,
                            fontSize = 11.sp,
                            color = ErrorRed,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                // Interactive Action Buttons with 48dp minimum touch target
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    when (task.status) {
                        DownloadStatus.DOWNLOADING, DownloadStatus.CONNECTING -> {
                            IconButton(
                                onClick = { onPause(task.id) },
                                modifier = Modifier.size(44.dp).testTag("action_pause_${task.id}")
                            ) {
                                Icon(Icons.Default.Pause, "Pausar", tint = PausedAmber)
                            }
                            IconButton(
                                onClick = { onCancel(task.id) },
                                modifier = Modifier.size(44.dp).testTag("action_cancel_${task.id}")
                            ) {
                                Icon(Icons.Default.Close, "Cancelar", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        DownloadStatus.PAUSED -> {
                            IconButton(
                                onClick = { onResume(task.id) },
                                modifier = Modifier.size(44.dp).testTag("action_resume_${task.id}")
                            ) {
                                Icon(Icons.Default.PlayArrow, "Continuar", tint = CyanPrimary)
                            }
                            IconButton(
                                onClick = { onCancel(task.id) },
                                modifier = Modifier.size(44.dp).testTag("action_cancel_${task.id}")
                            ) {
                                Icon(Icons.Default.Close, "Cancelar", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        DownloadStatus.FAILED -> {
                            IconButton(
                                onClick = { onRetry(task.id) },
                                modifier = Modifier.size(44.dp).testTag("action_retry_${task.id}")
                            ) {
                                Icon(Icons.Default.Refresh, "Tentar novamente", tint = CyanPrimary)
                            }
                            IconButton(
                                onClick = { onDelete(task.id) },
                                modifier = Modifier.size(44.dp).testTag("action_delete_${task.id}")
                            ) {
                                Icon(Icons.Default.Delete, "Excluir", tint = ErrorRed)
                            }
                        }
                        DownloadStatus.COMPLETED -> {
                            IconButton(
                                onClick = { onOpen(task.destinationPath, task.mimeType) },
                                modifier = Modifier.size(44.dp).testTag("action_open_${task.id}")
                            ) {
                                Icon(Icons.Default.OpenInNew, "Abrir", tint = CyanPrimary)
                            }
                            IconButton(
                                onClick = { onShare(task.destinationPath, task.mimeType) },
                                modifier = Modifier.size(44.dp).testTag("action_share_${task.id}")
                            ) {
                                Icon(Icons.Default.Share, "Compartilhar", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        else -> {}
                    }
                }
            }
        }
    }
}
