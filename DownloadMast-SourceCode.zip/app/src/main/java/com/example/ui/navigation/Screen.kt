package com.example.ui.navigation

sealed class Screen(val route: String, val title: String) {
    object Dashboard : Screen("dashboard", "Painel")
    object NewDownload : Screen("new_download", "Novo Download")
    object ActiveDownloads : Screen("active_downloads", "Em Andamento")
    object CompletedDownloads : Screen("completed_downloads", "Concluídos")
    object PausedDownloads : Screen("paused_downloads", "Pausados")
    object FileManager : Screen("file_manager", "Arquivos")
    object History : Screen("history", "Histórico")
    object Settings : Screen("settings", "Ajustes")
    object About : Screen("about", "Sobre")
}
