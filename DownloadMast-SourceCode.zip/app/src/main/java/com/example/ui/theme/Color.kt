package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Download Mast Signature Theme Palette
val CyanPrimary = Color(0xFF00D2FF)
val CyanOnPrimary = Color(0xFF003642)
val CyanPrimaryContainer = Color(0xFF004E5F)
val CyanOnPrimaryContainer = Color(0xFFB5EFFF)

val BlueSecondary = Color(0xFF388AF6)
val BlueOnSecondary = Color(0xFF002B73)
val BlueSecondaryContainer = Color(0xFF0040A1)
val BlueOnSecondaryContainer = Color(0xFFD8E2FF)

val IndigoTertiary = Color(0xFF7C8EFF)
val IndigoOnTertiary = Color(0xFF102588)
val IndigoTertiaryContainer = Color(0xFF293EA1)
val IndigoOnTertiaryContainer = Color(0xFFDEE0FF)

// Dark Surfaces
val DarkBackground = Color(0xFF0A0F1D)
val DarkSurface = Color(0xFF10192D)
val DarkSurfaceVariant = Color(0xFF182440)
val DarkSurfaceElevated = Color(0xFF202E50)
val DarkOutline = Color(0xFF2C3E68)
val DarkOutlineVariant = Color(0xFF1E2D4C)

val DarkTextPrimary = Color(0xFFF0F4FC)
val DarkTextSecondary = Color(0xFF94A7C6)
val DarkTextMuted = Color(0xFF5E7399)

// Light Theme Variants
val LightBackground = Color(0xFFF7F9FC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEEF2F8)
val LightOutline = Color(0xFFCBD5E1)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF475569)

// Status Colors
val SpeedAccentGreen = Color(0xFF00E676)
val SpeedAccentOrange = Color(0xFFFF9100)
val ErrorRed = Color(0xFFFF5252)
val PausedAmber = Color(0xFFFFB74D)
