package com.example.engine

import com.example.data.model.UrlMetadata
import com.example.util.FileUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.net.URLDecoder
import java.util.concurrent.TimeUnit

class UrlInspector(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()
) {

    suspend fun inspectUrl(rawUrl: String): UrlMetadata = withContext(Dispatchers.IO) {
        val url = rawUrl.trim()
        if (!url.startsWith("http://", ignoreCase = true) && !url.startsWith("https://", ignoreCase = true)) {
            return@withContext UrlMetadata(
                url = url,
                fileName = "arquivo",
                fileSize = -1L,
                mimeType = "application/octet-stream",
                supportsRange = false,
                isReachable = false,
                errorMessage = "URL inválida. O link deve começar com http:// ou https://"
            )
        }

        try {
            // First attempt: HEAD request to minimize bandwidth
            val headRequest = Request.Builder()
                .url(url)
                .head()
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile) DownloadMast/1.0")
                .build()

            val headResponse = try {
                client.newCall(headRequest).execute()
            } catch (e: Exception) {
                null
            }

            if (headResponse != null && headResponse.isSuccessful) {
                val contentLength = headResponse.header("Content-Length")?.toLongOrNull() ?: -1L
                val contentType = headResponse.header("Content-Type") ?: "application/octet-stream"
                val acceptRanges = headResponse.header("Accept-Ranges")
                val disposition = headResponse.header("Content-Disposition")
                val finalUrl = headResponse.request.url.toString()
                headResponse.close()

                val fileName = extractFileName(disposition, finalUrl, contentType)
                val supportsRange = acceptRanges?.contains("bytes", ignoreCase = true) == true

                return@withContext UrlMetadata(
                    url = finalUrl,
                    fileName = fileName,
                    fileSize = contentLength,
                    mimeType = contentType,
                    supportsRange = supportsRange,
                    isReachable = true
                )
            }

            // Fallback: Test with Range 0-0 GET request if HEAD is blocked (e.g. 403, 405 Method Not Allowed)
            val rangeRequest = Request.Builder()
                .url(url)
                .header("Range", "bytes=0-0")
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile) DownloadMast/1.0")
                .build()

            client.newCall(rangeRequest).execute().use { response ->
                if (response.isSuccessful || response.code == 206) {
                    val contentRange = response.header("Content-Range")
                    val contentType = response.header("Content-Type") ?: "application/octet-stream"
                    val disposition = response.header("Content-Disposition")
                    val finalUrl = response.request.url.toString()

                    var totalLength = -1L
                    var supportsRange = false

                    if (response.code == 206 && contentRange != null) {
                        supportsRange = true
                        val totalStr = contentRange.substringAfterLast('/', "")
                        totalLength = totalStr.toLongOrNull() ?: -1L
                    } else {
                        totalLength = response.header("Content-Length")?.toLongOrNull() ?: -1L
                        supportsRange = response.header("Accept-Ranges")?.contains("bytes", ignoreCase = true) == true
                    }

                    val fileName = extractFileName(disposition, finalUrl, contentType)

                    return@withContext UrlMetadata(
                        url = finalUrl,
                        fileName = fileName,
                        fileSize = totalLength,
                        mimeType = contentType,
                        supportsRange = supportsRange,
                        isReachable = true
                    )
                } else {
                    return@withContext UrlMetadata(
                        url = url,
                        fileName = extractFileName(null, url, "application/octet-stream"),
                        fileSize = -1L,
                        mimeType = "application/octet-stream",
                        supportsRange = false,
                        isReachable = false,
                        errorMessage = "Servidor respondeu com código de erro HTTP ${response.code}"
                    )
                }
            }

        } catch (e: IOException) {
            return@withContext UrlMetadata(
                url = url,
                fileName = extractFileName(null, url, "application/octet-stream"),
                fileSize = -1L,
                mimeType = "application/octet-stream",
                supportsRange = false,
                isReachable = false,
                errorMessage = "Falha de conexão com o servidor: ${e.localizedMessage ?: "Erro de rede"}"
            )
        } catch (e: Exception) {
            return@withContext UrlMetadata(
                url = url,
                fileName = extractFileName(null, url, "application/octet-stream"),
                fileSize = -1L,
                mimeType = "application/octet-stream",
                supportsRange = false,
                isReachable = false,
                errorMessage = "Erro inesperado: ${e.localizedMessage ?: "Erro desconhecido"}"
            )
        }
    }

    private fun extractFileName(disposition: String?, url: String, contentType: String): String {
        // Try Content-Disposition filename* or filename
        if (!disposition.isNullOrBlank()) {
            val starMatch = Regex("""filename\*\s*=\s*(?:UTF-8''|utf-8'')([^;]+)""", RegexOption.IGNORE_CASE).find(disposition)
            if (starMatch != null) {
                return try {
                    FileUtils.cleanFileName(URLDecoder.decode(starMatch.groupValues[1].trim('"'), "UTF-8"))
                } catch (e: Exception) {
                    FileUtils.cleanFileName(starMatch.groupValues[1].trim('"'))
                }
            }
            val regularMatch = Regex("""filename\s*=\s*"?([^";]+)"?""", RegexOption.IGNORE_CASE).find(disposition)
            if (regularMatch != null) {
                return FileUtils.cleanFileName(regularMatch.groupValues[1].trim('"'))
            }
        }

        // Try URL path
        try {
            val uriPath = url.substringBefore('?').substringBefore('#')
            val lastSegment = uriPath.substringAfterLast('/', "")
            if (lastSegment.isNotBlank() && lastSegment.contains('.')) {
                return FileUtils.cleanFileName(URLDecoder.decode(lastSegment, "UTF-8"))
            }
        } catch (_: Exception) {}

        // Fallback generic name based on timestamp and mime
        val ext = when {
            contentType.contains("pdf") -> ".pdf"
            contentType.contains("zip") -> ".zip"
            contentType.contains("mp4") -> ".mp4"
            contentType.contains("mp3") -> ".mp3"
            contentType.contains("jpeg") -> ".jpg"
            contentType.contains("png") -> ".png"
            else -> ""
        }
        return "download_${System.currentTimeMillis()}$ext"
    }
}
