package com.example.engine

class SpeedTracker {
    private var lastCalculationTime: Long = System.currentTimeMillis()
    private var lastDownloadedBytes: Long = 0L
    private var currentSpeed: Long = 0L
    private val speedHistory = ArrayDeque<Long>(5)

    fun updateProgress(currentTotalDownloaded: Long, totalFileSize: Long): Pair<Long, Long> {
        val now = System.currentTimeMillis()
        val timeDeltaMs = now - lastCalculationTime

        if (timeDeltaMs >= 600) {
            val bytesDelta = (currentTotalDownloaded - lastDownloadedBytes).coerceAtLeast(0L)
            val instantaneousSpeed = (bytesDelta * 1000L) / timeDeltaMs

            if (speedHistory.size >= 5) {
                speedHistory.removeFirst()
            }
            speedHistory.addLast(instantaneousSpeed)

            currentSpeed = if (speedHistory.isNotEmpty()) {
                speedHistory.sum() / speedHistory.size
            } else {
                instantaneousSpeed
            }

            lastCalculationTime = now
            lastDownloadedBytes = currentTotalDownloaded
        }

        val eta = if (currentSpeed > 0 && totalFileSize > currentTotalDownloaded) {
            val remainingBytes = totalFileSize - currentTotalDownloaded
            remainingBytes / currentSpeed
        } else {
            0L
        }

        return Pair(currentSpeed, eta)
    }

    fun reset(initialDownloadedBytes: Long = 0L) {
        lastCalculationTime = System.currentTimeMillis()
        lastDownloadedBytes = initialDownloadedBytes
        currentSpeed = 0L
        speedHistory.clear()
    }
}
