package com.example.engine

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.InputStream
import java.io.RandomAccessFile
import kotlin.coroutines.coroutineContext

class DownloadSegmentWorker(
    private val client: OkHttpClient,
    private val url: String,
    private val destinationFile: File,
    private val chunkIndex: Int,
    private val startByte: Long,
    private val endByte: Long,
    private val initialDownloaded: Long = 0L,
    private val onChunkProgress: (chunkIndex: Int, newDownloadedForChunk: Long, deltaBytes: Long) -> Unit
) {

    suspend fun execute(): Boolean = withContext(Dispatchers.IO) {
        val currentOffset = startByte + initialDownloaded
        if (currentOffset > endByte) {
            // Chunk already finished
            return@withContext true
        }

        val request = Request.Builder()
            .url(url)
            .header("Range", "bytes=$currentOffset-$endByte")
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile) DownloadMast/1.0")
            .build()

        val response = client.newCall(request).execute()
        if (!response.isSuccessful && response.code != 206) {
            response.close()
            throw IllegalStateException("Segment $chunkIndex download HTTP error ${response.code}")
        }

        val body = response.body ?: throw IllegalStateException("Segment $chunkIndex response body is null")
        val inputStream: InputStream = body.byteStream()

        var raf: RandomAccessFile? = null
        try {
            raf = RandomAccessFile(destinationFile, "rw")
            raf.seek(currentOffset)

            val buffer = ByteArray(16 * 1024)
            var bytesRead: Int
            var totalChunkDownloaded = initialDownloaded

            while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                coroutineContext.ensureActive()

                raf.write(buffer, 0, bytesRead)
                totalChunkDownloaded += bytesRead
                onChunkProgress(chunkIndex, totalChunkDownloaded, bytesRead.toLong())
            }

            raf.fd.sync()
            return@withContext true
        } finally {
            try {
                inputStream.close()
            } catch (_: Exception) {}
            try {
                raf?.close()
            } catch (_: Exception) {}
            response.close()
        }
    }
}
