package com.example.engine

import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.data.local.AppDatabase
import com.example.data.local.DownloadChunkEntity
import com.example.data.local.DownloadTaskEntity
import com.example.data.model.DownloadStatus
import com.example.data.model.FileCategory
import com.example.data.preferences.PreferencesManager
import com.example.service.DownloadForegroundService
import com.example.util.FileUtils
import com.example.util.NetworkUtils
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.RandomAccessFile
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

class DownloadEngine(
    private val context: Context,
    private val database: AppDatabase,
    private val preferencesManager: PreferencesManager,
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
) {

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    private val inspector = UrlInspector(client)

    // Active download jobs keyed by taskId
    private val activeJobs = ConcurrentHashMap<String, Job>()
    private val speedTrackers = ConcurrentHashMap<String, SpeedTracker>()

    private val _totalActiveSpeed = MutableStateFlow(0L)
    val totalActiveSpeed: StateFlow<Long> = _totalActiveSpeed.asStateFlow()

    private val _activeDownloadsCount = MutableStateFlow(0)
    val activeDownloadsCount: StateFlow<Int> = _activeDownloadsCount.asStateFlow()

    init {
        // Monitor active speeds and auto-queue
        scope.launch {
            while (true) {
                delay(1000)
                updateGlobalMetrics()
                checkAndStartQueuedTasks()
            }
        }
    }

    private fun updateGlobalMetrics() {
        var totalSpeed = 0L
        for (tracker in speedTrackers.values) {
            val (speed, _) = tracker.updateProgress(0, 0)
            totalSpeed += speed
        }
        _totalActiveSpeed.value = totalSpeed
        _activeDownloadsCount.value = activeJobs.size
    }

    private suspend fun checkAndStartQueuedTasks() {
        val maxConcurrent = preferencesManager.userPreferences.value.maxConcurrentDownloads
        if (activeJobs.size >= maxConcurrent) return

        if (preferencesManager.userPreferences.value.downloadOnlyOnWifi && !NetworkUtils.isWifiConnected(context)) {
            return
        }

        val dao = database.downloadDao()
        val allTasks = dao.getTaskById("dummy") // Quick db check
        // Check pending tasks in DB
        // We will query pending tasks
    }

    fun getDownloadDirectory(): File {
        val dir = File(context.getExternalFilesDir(null), "DownloadMast")
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    suspend fun enqueueDownload(
        url: String,
        customFileName: String? = null,
        threadCount: Int? = null
    ): String = withContext(Dispatchers.IO) {
        val metadata = inspector.inspectUrl(url)
        val finalFileName = if (!customFileName.isNullOrBlank()) {
            FileUtils.cleanFileName(customFileName)
        } else {
            metadata.fileName
        }

        val destinationDir = getDownloadDirectory()
        val destinationFile = File(destinationDir, finalFileName)
        val taskId = UUID.randomUUID().toString()

        val chosenThreads = threadCount ?: preferencesManager.userPreferences.value.maxThreadsPerDownload
        val category = FileUtils.determineCategory(finalFileName, metadata.mimeType)

        val task = DownloadTaskEntity(
            id = taskId,
            url = metadata.url,
            fileName = finalFileName,
            destinationPath = destinationFile.absolutePath,
            fileSize = metadata.fileSize,
            downloadedBytes = 0L,
            mimeType = metadata.mimeType,
            status = DownloadStatus.PENDING,
            isRangeSupported = metadata.supportsRange,
            threadCount = if (metadata.supportsRange && metadata.fileSize > 1024 * 1024) chosenThreads else 1,
            category = category
        )

        database.downloadDao().insertTask(task)
        startDownloadTask(taskId)
        return@withContext taskId
    }

    fun startDownloadTask(taskId: String) {
        if (activeJobs.containsKey(taskId)) return

        val job = scope.launch(Dispatchers.IO) {
            runDownloadPipeline(taskId)
        }
        activeJobs[taskId] = job
        updateServiceState()
    }

    fun pauseDownload(taskId: String) {
        val job = activeJobs.remove(taskId)
        job?.cancel()
        speedTrackers.remove(taskId)

        scope.launch(Dispatchers.IO) {
            database.downloadDao().updateTaskProgress(taskId, -1L, 0L, 0L)
            database.downloadDao().updateTaskStatus(taskId, DownloadStatus.PAUSED)
            updateServiceState()
        }
    }

    fun resumeDownload(taskId: String) {
        scope.launch(Dispatchers.IO) {
            val task = database.downloadDao().getTaskById(taskId) ?: return@launch
            if (task.status == DownloadStatus.PAUSED || task.status == DownloadStatus.FAILED) {
                database.downloadDao().updateTaskStatus(taskId, DownloadStatus.PENDING)
                startDownloadTask(taskId)
            }
        }
    }

    fun cancelDownload(taskId: String) {
        val job = activeJobs.remove(taskId)
        job?.cancel()
        speedTrackers.remove(taskId)

        scope.launch(Dispatchers.IO) {
            val task = database.downloadDao().getTaskById(taskId)
            if (task != null) {
                // Delete partial file
                val file = File(task.destinationPath)
                if (file.exists() && task.status != DownloadStatus.COMPLETED) {
                    file.delete()
                }
                database.downloadDao().deleteChunksForTask(taskId)
                database.downloadDao().updateTaskStatus(taskId, DownloadStatus.CANCELLED)
            }
            updateServiceState()
        }
    }

    fun retryDownload(taskId: String) {
        resumeDownload(taskId)
    }

    suspend fun deleteDownload(taskId: String, deleteFileFromDisk: Boolean = true) = withContext(Dispatchers.IO) {
        cancelDownload(taskId)
        val task = database.downloadDao().getTaskById(taskId)
        if (task != null && deleteFileFromDisk) {
            val file = File(task.destinationPath)
            if (file.exists()) {
                file.delete()
            }
        }
        database.downloadDao().deleteTask(taskId)
    }

    suspend fun renameDownload(taskId: String, newName: String): Boolean = withContext(Dispatchers.IO) {
        val task = database.downloadDao().getTaskById(taskId) ?: return@withContext false
        val cleanName = FileUtils.cleanFileName(newName)
        val oldFile = File(task.destinationPath)
        val newFile = File(oldFile.parentFile ?: getDownloadDirectory(), cleanName)

        val success = if (oldFile.exists()) {
            oldFile.renameTo(newFile)
        } else {
            true
        }

        if (success) {
            val newCategory = FileUtils.determineCategory(cleanName, task.mimeType)
            database.downloadDao().renameTask(taskId, cleanName, newFile.absolutePath, newCategory)
            return@withContext true
        }
        return@withContext false
    }

    private suspend fun runDownloadPipeline(taskId: String) {
        val dao = database.downloadDao()
        val task = dao.getTaskById(taskId) ?: return

        // Verify network restriction
        if (preferencesManager.userPreferences.value.downloadOnlyOnWifi && !NetworkUtils.isWifiConnected(context)) {
            dao.markTaskFailed(taskId, "Download pausado: Configurado para baixar apenas via Wi-Fi")
            activeJobs.remove(taskId)
            updateServiceState()
            return
        }

        dao.updateTaskStatus(taskId, DownloadStatus.CONNECTING)

        val tracker = SpeedTracker()
        tracker.reset(task.downloadedBytes)
        speedTrackers[taskId] = tracker

        val destinationFile = File(task.destinationPath)
        val parent = destinationFile.parentFile
        if (parent != null && !parent.exists()) {
            parent.mkdirs()
        }

        try {
            if (task.isRangeSupported && task.threadCount > 1 && task.fileSize > 0) {
                // Multi-threaded chunk download
                executeMultiSegmentDownload(task, destinationFile, tracker)
            } else {
                // Single-stream download (stream/chunked or range unsupported)
                executeSingleStreamDownload(task, destinationFile, tracker)
            }

            // On success
            dao.markTaskCompleted(taskId)
        } catch (e: CancellationException) {
            // Task was paused or cancelled by user
            dao.updateTaskStatus(taskId, DownloadStatus.PAUSED)
        } catch (e: Exception) {
            e.printStackTrace()
            val msg = e.localizedMessage ?: "Erro na transferência do arquivo"
            dao.markTaskFailed(taskId, msg)
        } finally {
            activeJobs.remove(taskId)
            speedTrackers.remove(taskId)
            updateServiceState()
        }
    }

    private suspend fun executeMultiSegmentDownload(
        task: DownloadTaskEntity,
        destinationFile: File,
        tracker: SpeedTracker
    ) {
        val dao = database.downloadDao()
        val taskId = task.id
        val fileSize = task.fileSize
        val threadCount = task.threadCount

        // Pre-allocate or ensure file existence
        if (!destinationFile.exists()) {
            val raf = RandomAccessFile(destinationFile, "rw")
            raf.setLength(fileSize)
            raf.close()
        }

        // Get or create chunks
        var chunks = dao.getChunksForTask(taskId)
        if (chunks.isEmpty()) {
            val chunkSize = fileSize / threadCount
            val chunkList = mutableListOf<DownloadChunkEntity>()
            for (i in 0 until threadCount) {
                val start = i * chunkSize
                val end = if (i == threadCount - 1) fileSize - 1 else (start + chunkSize - 1)
                chunkList.add(
                    DownloadChunkEntity(
                        id = "${taskId}_chunk_$i",
                        taskId = taskId,
                        chunkIndex = i,
                        startByte = start,
                        endByte = end,
                        downloadedBytes = 0L,
                        isCompleted = false
                    )
                )
            }
            dao.insertChunks(chunkList)
            chunks = chunkList
        }

        dao.updateTaskStatus(taskId, DownloadStatus.DOWNLOADING)

        var totalDownloaded = chunks.sumOf { it.downloadedBytes }
        var lastDbUpdateTime = System.currentTimeMillis()

        val workers = chunks.map { chunk ->
            scope.async(Dispatchers.IO) {
                if (chunk.isCompleted) return@async true

                val worker = DownloadSegmentWorker(
                    client = client,
                    url = task.url,
                    destinationFile = destinationFile,
                    chunkIndex = chunk.chunkIndex,
                    startByte = chunk.startByte,
                    endByte = chunk.endByte,
                    initialDownloaded = chunk.downloadedBytes
                ) { chunkIndex, newChunkDownloaded, deltaBytes ->
                    totalDownloaded += deltaBytes
                    val (speed, eta) = tracker.updateProgress(totalDownloaded, fileSize)

                    val now = System.currentTimeMillis()
                    if (now - lastDbUpdateTime > 800) {
                        lastDbUpdateTime = now
                        scope.launch(Dispatchers.IO) {
                            dao.updateTaskProgress(taskId, totalDownloaded, speed, eta)
                            val isChunkDone = newChunkDownloaded >= (chunk.endByte - chunk.startByte + 1)
                            dao.updateChunkProgress("${taskId}_chunk_$chunkIndex", newChunkDownloaded, isChunkDone)
                        }
                    }
                }
                val success = worker.execute()
                dao.updateChunkProgress(chunk.id, chunk.endByte - chunk.startByte + 1, true)
                success
            }
        }

        workers.awaitAll()
    }

    private suspend fun executeSingleStreamDownload(
        task: DownloadTaskEntity,
        destinationFile: File,
        tracker: SpeedTracker
    ) {
        val dao = database.downloadDao()
        val taskId = task.id
        val alreadyDownloaded = destinationFile.length()

        val requestBuilder = Request.Builder()
            .url(task.url)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile) DownloadMast/1.0")

        if (alreadyDownloaded > 0 && task.isRangeSupported) {
            requestBuilder.header("Range", "bytes=$alreadyDownloaded-")
        }

        val request = requestBuilder.build()
        val response = client.newCall(request).execute()

        if (!response.isSuccessful && response.code != 206) {
            response.close()
            throw IllegalStateException("Servidor retornou erro HTTP ${response.code}")
        }

        val body = response.body ?: throw IllegalStateException("Corpo da resposta vazio")
        val inputStream: InputStream = body.byteStream()
        val append = (response.code == 206 && alreadyDownloaded > 0)
        val outputStream = FileOutputStream(destinationFile, append)

        dao.updateTaskStatus(taskId, DownloadStatus.DOWNLOADING)

        var currentDownloaded = if (append) alreadyDownloaded else 0L
        val totalExpected = if (task.fileSize > 0) task.fileSize else (currentDownloaded + body.contentLength())
        var lastDbUpdateTime = System.currentTimeMillis()

        try {
            val buffer = ByteArray(16 * 1024)
            var bytesRead: Int

            while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                outputStream.write(buffer, 0, bytesRead)
                currentDownloaded += bytesRead

                val (speed, eta) = tracker.updateProgress(currentDownloaded, totalExpected)
                val now = System.currentTimeMillis()
                if (now - lastDbUpdateTime > 800) {
                    lastDbUpdateTime = now
                    dao.updateTaskProgress(taskId, currentDownloaded, speed, eta)
                }
            }
            outputStream.flush()
        } finally {
            try { outputStream.close() } catch (_: Exception) {}
            try { inputStream.close() } catch (_: Exception) {}
            response.close()
        }
    }

    private fun updateServiceState() {
        val count = activeJobs.size
        val intent = Intent(context, DownloadForegroundService::class.java)
        if (count > 0) {
            intent.action = DownloadForegroundService.ACTION_UPDATE_STATUS
            intent.putExtra("active_count", count)
            intent.putExtra("total_speed", _totalActiveSpeed.value)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                try {
                    context.startForegroundService(intent)
                } catch (_: Exception) {}
            } else {
                context.startService(intent)
            }
        } else {
            intent.action = DownloadForegroundService.ACTION_STOP
            context.startService(intent)
        }
    }
}
