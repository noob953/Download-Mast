package com.example

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.ui.navigation.DownloadMastApp
import com.example.ui.theme.DownloadMastTheme
import com.example.ui.viewmodel.DownloadViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: DownloadViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Extract any shared URL passed from other apps via Intent.ACTION_SEND
        val sharedUrl = extractSharedUrl(intent)

        setContent {
            val preferences by viewModel.userPreferences.collectAsState()
            val systemDark = isSystemInDarkTheme()

            val isDarkTheme = when (preferences.themeMode) {
                "DARK" -> true
                "LIGHT" -> false
                else -> systemDark
            }

            // Notification permission request for Android 13+ (API 33+)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val notificationPermissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission()
                ) { /* Graceful permission handling */ }

                LaunchedEffect(Unit) {
                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }

            DownloadMastTheme(darkTheme = isDarkTheme) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    DownloadMastApp(
                        viewModel = viewModel,
                        sharedUrl = sharedUrl
                    )
                }
            }
        }
    }

    private fun extractSharedUrl(intent: Intent?): String? {
        if (intent?.action == Intent.ACTION_SEND && intent.type == "text/plain") {
            val text = intent.getStringExtra(Intent.EXTRA_TEXT)
            if (!text.isNullOrBlank()) {
                // Find http or https link in text
                val urlRegex = Regex("""https?://[^\s]+""", RegexOption.IGNORE_CASE)
                val match = urlRegex.find(text)
                return match?.value ?: text.trim()
            }
        }
        return null
    }
}
