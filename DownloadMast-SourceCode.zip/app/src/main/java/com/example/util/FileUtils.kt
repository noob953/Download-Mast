package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.model.FileCategory
import java.io.File
import java.util.Locale

object FileUtils {

    fun determineCategory(fileName: String, mimeType: String?): FileCategory {
        val extension = getFileExtension(fileName).lowercase(Locale.ROOT)
        val mime = (mimeType ?: "").lowercase(Locale.ROOT)

        return when {
            mime.startsWith("video/") || extension in listOf("mp4", "mkv", "avi", "mov", "webm", "flv", "wmv", "3gp", "m4v") -> {
                FileCategory.VIDEO
            }
            mime.startsWith("audio/") || extension in listOf("mp3", "wav", "flac", "aac", "m4a", "ogg", "wma", "opus") -> {
                FileCategory.AUDIO
            }
            mime.startsWith("image/") || extension in listOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "svg", "ico") -> {
                FileCategory.IMAGE
            }
            mime.startsWith("text/") || mime.contains("pdf") || mime.contains("document") || mime.contains("sheet") || mime.contains("presentation") ||
                    extension in listOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "csv", "epub", "md", "rtf") -> {
                FileCategory.DOCUMENT
            }
            mime.contains("zip") || mime.contains("tar") || mime.contains("compressed") ||
                    extension in listOf("zip", "rar", "7z", "tar", "gz", "bz2", "xz", "iso", "apk") -> {
                FileCategory.ARCHIVE
            }
            else -> FileCategory.OTHER
        }
    }

    fun getFileExtension(fileName: String): String {
        val lastDotIndex = fileName.lastIndexOf('.')
        return if (lastDotIndex != -1 && lastDotIndex < fileName.length - 1) {
            fileName.substring(lastDotIndex + 1)
        } else {
            ""
        }
    }

    fun getMimeType(fileName: String): String {
        val extension = getFileExtension(fileName).lowercase(Locale.ROOT)
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension) ?: "application/octet-stream"
    }

    fun cleanFileName(rawName: String): String {
        // Strip query parameters and illegal characters
        var cleaned = rawName.substringBefore('?').substringBefore('#')
        if (cleaned.contains('/')) {
            cleaned = cleaned.substringAfterLast('/')
        }
        // Replace reserved characters
        cleaned = cleaned.replace("[\\\\/:*?\"<>|]".toRegex(), "_").trim()
        if (cleaned.isBlank()) {
            cleaned = "download_${System.currentTimeMillis()}"
        }
        return cleaned
    }

    fun openFile(context: Context, filePath: String, mimeType: String) {
        try {
            val file = File(filePath)
            if (!file.exists()) {
                Toast.makeText(context, "Arquivo não encontrado no dispositivo", Toast.LENGTH_SHORT).show()
                return
            }
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mimeType.ifBlank { getMimeType(file.name) })
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "Abrir com...").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (e: Exception) {
            Toast.makeText(context, "Nenhum aplicativo encontrado para abrir este arquivo", Toast.LENGTH_LONG).show()
        }
    }

    fun shareFile(context: Context, filePath: String, mimeType: String) {
        try {
            val file = File(filePath)
            if (!file.exists()) {
                Toast.makeText(context, "Arquivo não encontrado", Toast.LENGTH_SHORT).show()
                return
            }
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType.ifBlank { getMimeType(file.name) }
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, file.name)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Compartilhar arquivo").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (e: Exception) {
            Toast.makeText(context, "Erro ao compartilhar arquivo: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }
}
