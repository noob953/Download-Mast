package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.DownloadStatus
import com.example.data.model.FileCategory
import kotlinx.coroutines.flow.Flow

@Dao
interface DownloadDao {

    @Query("SELECT * FROM download_tasks ORDER BY createdAt DESC")
    fun getAllTasks(): Flow<List<DownloadTaskEntity>>

    @Query("SELECT * FROM download_tasks WHERE status IN ('PENDING', 'CONNECTING', 'DOWNLOADING') ORDER BY createdAt DESC")
    fun getActiveTasks(): Flow<List<DownloadTaskEntity>>

    @Query("SELECT * FROM download_tasks WHERE status = 'COMPLETED' ORDER BY completedAt DESC, createdAt DESC")
    fun getCompletedTasks(): Flow<List<DownloadTaskEntity>>

    @Query("SELECT * FROM download_tasks WHERE status = 'PAUSED' ORDER BY createdAt DESC")
    fun getPausedTasks(): Flow<List<DownloadTaskEntity>>

    @Query("SELECT * FROM download_tasks WHERE status IN ('COMPLETED', 'FAILED', 'CANCELLED') ORDER BY createdAt DESC")
    fun getHistoryTasks(): Flow<List<DownloadTaskEntity>>

    @Query("SELECT * FROM download_tasks WHERE status = 'COMPLETED' AND (:category = 'ALL' OR category = :category) AND (:query = '' OR fileName LIKE '%' || :query || '%') ORDER BY completedAt DESC")
    fun getFilteredCompletedFiles(category: String, query: String): Flow<List<DownloadTaskEntity>>

    @Query("SELECT * FROM download_tasks ORDER BY createdAt DESC LIMIT 5")
    fun getRecentTasks(): Flow<List<DownloadTaskEntity>>

    @Query("SELECT * FROM download_tasks WHERE id = :taskId")
    suspend fun getTaskById(taskId: String): DownloadTaskEntity?

    @Query("SELECT * FROM download_tasks WHERE id = :taskId")
    fun getTaskByIdFlow(taskId: String): Flow<DownloadTaskEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: DownloadTaskEntity)

    @Update
    suspend fun updateTask(task: DownloadTaskEntity)

    @Query("UPDATE download_tasks SET status = :status WHERE id = :taskId")
    suspend fun updateTaskStatus(taskId: String, status: DownloadStatus)

    @Query("UPDATE download_tasks SET downloadedBytes = :downloaded, speedBytesPerSec = :speed, etaSeconds = :eta WHERE id = :taskId")
    suspend fun updateTaskProgress(taskId: String, downloaded: Long, speed: Long, eta: Long)

    @Query("UPDATE download_tasks SET status = 'COMPLETED', downloadedBytes = fileSize, completedAt = :completedAt, speedBytesPerSec = 0, etaSeconds = 0 WHERE id = :taskId")
    suspend fun markTaskCompleted(taskId: String, completedAt: Long = System.currentTimeMillis())

    @Query("UPDATE download_tasks SET status = 'FAILED', errorMessage = :errorMessage, speedBytesPerSec = 0 WHERE id = :taskId")
    suspend fun markTaskFailed(taskId: String, errorMessage: String)

    @Query("UPDATE download_tasks SET fileName = :newName, destinationPath = :newPath, category = :category WHERE id = :taskId")
    suspend fun renameTask(taskId: String, newName: String, newPath: String, category: FileCategory)

    @Query("DELETE FROM download_tasks WHERE id = :taskId")
    suspend fun deleteTask(taskId: String)

    @Query("DELETE FROM download_tasks WHERE status IN ('COMPLETED', 'FAILED', 'CANCELLED')")
    suspend fun clearHistory()

    // Chunks
    @Query("SELECT * FROM download_chunks WHERE taskId = :taskId ORDER BY chunkIndex ASC")
    suspend fun getChunksForTask(taskId: String): List<DownloadChunkEntity>

    @Query("SELECT * FROM download_chunks WHERE taskId = :taskId ORDER BY chunkIndex ASC")
    fun getChunksForTaskFlow(taskId: String): Flow<List<DownloadChunkEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChunks(chunks: List<DownloadChunkEntity>)

    @Query("UPDATE download_chunks SET downloadedBytes = :downloaded, isCompleted = :isCompleted WHERE id = :chunkId")
    suspend fun updateChunkProgress(chunkId: String, downloaded: Long, isCompleted: Boolean)

    @Query("DELETE FROM download_chunks WHERE taskId = :taskId")
    suspend fun deleteChunksForTask(taskId: String)
}
