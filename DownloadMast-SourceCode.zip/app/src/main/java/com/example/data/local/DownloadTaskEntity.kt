package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.DownloadStatus
import com.example.data.model.FileCategory

@Entity(tableName = "download_tasks")
data class DownloadTaskEntity(
    @PrimaryKey
    val id: String,
    val url: String,
    val fileName: String,
    val destinationPath: String,
    val fileSize: Long, // in bytes (-1 if unknown)
    val downloadedBytes: Long = 0L,
    val mimeType: String = "application/octet-stream",
    val status: DownloadStatus = DownloadStatus.PENDING,
    val isRangeSupported: Boolean = false,
    val threadCount: Int = 4,
    val speedBytesPerSec: Long = 0L,
    val etaSeconds: Long = 0L,
    val errorMessage: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null,
    val category: FileCategory = FileCategory.OTHER
)
