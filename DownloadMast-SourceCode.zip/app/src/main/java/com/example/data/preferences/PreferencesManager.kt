package com.example.data.preferences

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class UserPreferences(
    val maxConcurrentDownloads: Int = 3,
    val maxThreadsPerDownload: Int = 4,
    val downloadOnlyOnWifi: Boolean = false,
    val showCompletionNotification: Boolean = true,
    val autoRetryOnFailure: Boolean = true,
    val themeMode: String = "DARK", // "DARK", "LIGHT", "SYSTEM"
    val speedLimitKbps: Int = 0 // 0 = unlimited
)

class PreferencesManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(
        "download_mast_prefs",
        Context.MODE_PRIVATE
    )

    private val _userPreferences = MutableStateFlow(loadPreferences())
    val userPreferences: StateFlow<UserPreferences> = _userPreferences.asStateFlow()

    private fun loadPreferences(): UserPreferences {
        return UserPreferences(
            maxConcurrentDownloads = prefs.getInt("max_concurrent_downloads", 3),
            maxThreadsPerDownload = prefs.getInt("max_threads_per_download", 4),
            downloadOnlyOnWifi = prefs.getBoolean("download_only_on_wifi", false),
            showCompletionNotification = prefs.getBoolean("show_completion_notification", true),
            autoRetryOnFailure = prefs.getBoolean("auto_retry_on_failure", true),
            themeMode = prefs.getString("theme_mode", "DARK") ?: "DARK",
            speedLimitKbps = prefs.getInt("speed_limit_kbps", 0)
        )
    }

    fun updateMaxConcurrentDownloads(value: Int) {
        val safe = value.coerceIn(1, 10)
        prefs.edit().putInt("max_concurrent_downloads", safe).apply()
        _userPreferences.value = _userPreferences.value.copy(maxConcurrentDownloads = safe)
    }

    fun updateMaxThreadsPerDownload(value: Int) {
        val safe = value.coerceIn(1, 8)
        prefs.edit().putInt("max_threads_per_download", safe).apply()
        _userPreferences.value = _userPreferences.value.copy(maxThreadsPerDownload = safe)
    }

    fun updateDownloadOnlyOnWifi(value: Boolean) {
        prefs.edit().putBoolean("download_only_on_wifi", value).apply()
        _userPreferences.value = _userPreferences.value.copy(downloadOnlyOnWifi = value)
    }

    fun updateShowCompletionNotification(value: Boolean) {
        prefs.edit().putBoolean("show_completion_notification", value).apply()
        _userPreferences.value = _userPreferences.value.copy(showCompletionNotification = value)
    }

    fun updateAutoRetryOnFailure(value: Boolean) {
        prefs.edit().putBoolean("auto_retry_on_failure", value).apply()
        _userPreferences.value = _userPreferences.value.copy(autoRetryOnFailure = value)
    }

    fun updateThemeMode(mode: String) {
        prefs.edit().putString("theme_mode", mode).apply()
        _userPreferences.value = _userPreferences.value.copy(themeMode = mode)
    }

    fun updateSpeedLimitKbps(limitKbps: Int) {
        val safe = limitKbps.coerceAtLeast(0)
        prefs.edit().putInt("speed_limit_kbps", safe).apply()
        _userPreferences.value = _userPreferences.value.copy(speedLimitKbps = safe)
    }
}
