package com.example.data.model

enum class DownloadStatus {
    PENDING,
    CONNECTING,
    DOWNLOADING,
    PAUSED,
    COMPLETED,
    FAILED,
    CANCELLED
}

enum class FileCategory(val label: String) {
    ALL("Todos"),
    VIDEO("Vídeos"),
    AUDIO("Músicas"),
    IMAGE("Imagens"),
    DOCUMENT("Documentos"),
    ARCHIVE("Compactados"),
    OTHER("Outros")
}

data class UrlMetadata(
    val url: String,
    val fileName: String,
    val fileSize: Long, // -1 if unknown (chunked/stream)
    val mimeType: String,
    val supportsRange: Boolean,
    val isReachable: Boolean,
    val errorMessage: String? = null
)

data class ChunkProgress(
    val chunkIndex: Int,
    val startByte: Long,
    val endByte: Long,
    val downloadedBytes: Long,
    val totalBytes: Long,
    val isCompleted: Boolean
)
