package com.example

import android.app.Application
import com.example.data.local.AppDatabase
import com.example.data.preferences.PreferencesManager
import com.example.engine.DownloadEngine

class DownloadMastApplication : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var preferencesManager: PreferencesManager
        private set

    lateinit var downloadEngine: DownloadEngine
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        database = AppDatabase.getDatabase(this)
        preferencesManager = PreferencesManager(this)
        downloadEngine = DownloadEngine(this, database, preferencesManager)
    }

    companion object {
        lateinit var instance: DownloadMastApplication
            private set
    }
}
