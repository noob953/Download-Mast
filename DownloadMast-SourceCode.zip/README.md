# Download Mast ⚡

**Download Mast** é um gerenciador de downloads profissional, moderno e de alta performance desenvolvido para Android utilizando **Kotlin** e **Jetpack Compose**. Projetado para acelerar transferências via internet através de segmentação inteligente por **HTTP Range**, downloads paralelos multi-thread, recuperação de conexões interrompidas, organização categorizada de arquivos e operação estável em segundo plano.

---

## 🚀 Funcionalidades Principais

- **Aceleração Multi-Segmento**: Suporte à divisão de arquivos em múltiplas partes paralelas (até 8 conexões simultâneas) utilizando cabeçalhos HTTP Range.
- **Detecção Automática de Metadados**: Pré-visualização instantânea do tamanho real, nome sugerido pelo servidor (`Content-Disposition`) e tipo MIME antes de iniciar.
- **Pausa, Retomada e Recuperação**: Interrompa downloads a qualquer momento e retome exatamente de onde parou sem perda de progresso graças à gravação indexada com `RandomAccessFile`.
- **Velocidade em Tempo Real & Estimativa (ETA)**: Cálculo contínuo da taxa de transferência em KB/s e MB/s com tempo estimado restante.
- **Downloads Simultâneos**: Fila com controle de concorrência configurável (1 a 10 downloads paralelos).
- **Gerenciador de Arquivos Integrado**:
  - Filtro por categorias: *Todos, Vídeos, Músicas, Imagens, Documentos, Compactados e Outros*.
  - Busca instantânea por nome.
  - Ações diretas: Abrir no player/visualizador do sistema, Compartilhar via `FileProvider`, Renomear e Excluir.
- **Histórico Completo**: Registro cronológico de todas as transferências com opção de limpeza rápida.
- **Operação em Segundo Plano Robusta**: `DownloadForegroundService` nativo do Android (`dataSync`) com notificações persistentes de progresso e gerenciamento de `WakeLock`.
- **Configurações Avançadas**:
  - Restrição para download somente via Wi-Fi.
  - Tentativas automáticas de reconexão em caso de oscilação de rede.
  - Tema escuro padrão com detalhes em ciano/azul elétrico e suporte a tema claro.

---

## 🛠️ Tecnologias Utilizadas

- **Linguagem**: Kotlin 2.2
- **Interface**: Jetpack Compose com Material Design 3 (M3)
- **Navegação**: Jetpack Navigation Compose
- **Persistência Local**: Room Database (SQLite) com Kotlin Coroutines & Flow
- **Cliente HTTP**: OkHttp 4.10 com suporte a streaming de chunks e pooling de conexões
- **Serviço em Segundo Plano**: Android Foreground Service (`android:foregroundServiceType="dataSync"`)
- **Compatibilidade de Arquivos**: Android `FileProvider` seguro para compartilhamento externo

---

## 📂 Estrutura do Projeto

```
app/src/main/
├── AndroidManifest.xml                  # Permissões, serviços e provedor de arquivos
├── java/com/example/
│   ├── MainActivity.kt                  # Activity principal com suporte a intents de compartilhamento
│   ├── DownloadMastApplication.kt       # Inicialização global do Room e DownloadEngine
│   ├── data/
│   │   ├── local/                       # Entidades e DAOs do Room (DownloadTask, DownloadChunk)
│   │   ├── model/                       # Modelos de dados (DownloadStatus, FileCategory, UrlMetadata)
│   │   └── preferences/                 # Gerenciador de configurações do usuário
│   ├── engine/
│   │   ├── DownloadEngine.kt            # Orquestrador central da fila e concorrência
│   │   ├── DownloadSegmentWorker.kt     # Worker de download por intervalo de bytes (HTTP Range)
│   │   ├── UrlInspector.kt              # Inspetor de cabeçalhos e capacidade de Range
│   │   └── SpeedTracker.kt              # Calculador de velocidade média e ETA
│   ├── service/
│   │   └── DownloadForegroundService.kt # Serviço persistente em segundo plano com notificações
│   ├── ui/
│   │   ├── components/                  # Componentes reutilizáveis (Cards, Barra de progresso, Filtros)
│   │   ├── navigation/                  # Navegação com barra inferior (Dashboard, Downloads, Arquivos, Histórico, Ajustes)
│   │   ├── screens/                     # As 9 telas completas da aplicação
│   │   └── theme/                       # Paleta ciano/azul moderna e esquema escuro
│   └── util/                            # Utilitários de rede, arquivos, formatação de bytes e datas
└── res/                                 # Drawables, ícones adaptativos e strings
```

---

## 💻 Instruções para Configuração do Ambiente e Compilação

### Pré-requisitos
1. **JDK 17 ou superior** instalado.
2. **Android Studio Iguana / Jellyfish / Ladybug** ou superior.
3. **Android SDK** com suporte à API 34 ou 36.

### Compilação via Linha de Comando (Gradle)

Para compilar o projeto e rodar as verificações:
```bash
gradle assembleDebug
```

Para executar os testes unitários e de integração:
```bash
gradle :app:testDebugUnitTest
```

### Como Gerar o APK para Android

1. **APK de Debug (Desenvolvimento e Teste Rápido)**:
   ```bash
   gradle assembleDebug
   ```
   O arquivo APK será gerado em:
   `app/build/outputs/apk/debug/app-debug.apk`

2. **APK de Release (Produção)**:
   ```bash
   gradle assembleRelease
   ```
   O arquivo APK será gerado em:
   `app/build/outputs/apk/release/app-release.apk`

---

## 📄 Licença

Este projeto está sob a licença [MIT](LICENSE).
